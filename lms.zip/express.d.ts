/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/consistent-type-definitions */
declare namespace Express {
  export interface Request {
    user: any
  }
}
