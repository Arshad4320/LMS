export type ICourse = {
  title: string
  thumbnail?: string
  price: number
  description: string
}
